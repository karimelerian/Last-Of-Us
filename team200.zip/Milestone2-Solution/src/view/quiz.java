package view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class quiz {
public static void main(String[]args) {
	JFrame frame = new JFrame();
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(1600, 834);
    frame.setLayout(new BorderLayout());
	JButton buttonright= new JButton();
    JButton buttonleft = new JButton();
    JButton buttonup = new JButton();
    JButton buttondown = new JButton();
    JButton buttonusespecial = new JButton();
    buttondown.setText("ellie");
    buttonright.setText("joel");
    buttonleft.setText("Tess");
    buttonup.setText("Tommy");
    buttonusespecial.setText("Rotate");
    JPanel panel = new JPanel(new GridLayout(1, 0));
    
    panel.setPreferredSize(new Dimension(200, 100));
    panel.add(buttonusespecial,BorderLayout.CENTER);
    frame.add(buttonusespecial, BorderLayout.CENTER);
    panel.add(buttonusespecial);
    panel.setVisible(true);
    
    frame.add(panel, BorderLayout.CENTER);
     panel = new JPanel(new GridLayout(1, 0));
    frame.add(buttonup,BorderLayout.NORTH);
     panel = new JPanel(new GridLayout(1, 0));
    frame.add(buttonright,BorderLayout.EAST);
     panel = new JPanel(new GridLayout(1, 0));
    frame.add(buttonleft,BorderLayout.SOUTH);
     panel = new JPanel(new GridLayout(1, 0));
    frame.add(buttondown,BorderLayout.WEST);
    frame.add(buttonusespecial,BorderLayout.CENTER);
    frame.add(panel);
    int k=0;
    frame.setVisible(true);
    
}

}
