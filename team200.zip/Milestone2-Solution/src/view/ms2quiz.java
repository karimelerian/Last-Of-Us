package view;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;

public class ms2quiz {
    private static int clickCount = 0; // Counter for button clicks

    public static void main(String[] args) {
        addbutton();
    }

    public static void addbutton() {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1600, 834);
        frame.setLayout(new BorderLayout());
        JPanel panel = new JPanel(new GridLayout(1, 0));
        panel.setPreferredSize(new Dimension(100, 100));

        // Set the color for the border
        Color borderColor = Color.RED;

        // Create a LineBorder with the specified color
        Border border = new LineBorder(borderColor, 3);

        

        frame.add(panel, BorderLayout.SOUTH);
        JPanel panel1 = new JPanel(new GridLayout(1, 1));
        panel1.setPreferredSize(new Dimension(50, 5));
        JButton buttonzombie = new JButton();
        buttonzombie.setText("Enlarge");
        panel.add(buttonzombie);
        JLabel label = new JLabel();
        panel1.add(label);
        panel1.setBorder(border);

        class ButtonClickListener implements ActionListener {
            @Override
            public void actionPerformed(ActionEvent e) {
                Object source = e.getSource();
                if (source == buttonzombie) {
                    clickCount++;
                    if (clickCount <= 2) {
                       // panel1.setPreferredSize(new Dimension(200 * clickCount, 100 * clickCount));
                        label.setText("zombie");
                    } else {
                        panel1.setPreferredSize(new Dimension(200, 100));
                        label.setText("huge zombie");
                    }
                  //  frame.pack(); // Adjust frame size to fit the new panel size
                }
            }
        }

        buttonzombie.addActionListener(new ButtonClickListener());
        frame.add(panel1, BorderLayout.WEST);
        frame.setVisible(true);
    }
}
