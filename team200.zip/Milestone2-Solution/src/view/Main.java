package view;
import engine.Game;
import exceptions.InvalidTargetException;
import exceptions.MovementException;
import exceptions.NoAvailableResourcesException;
import exceptions.NotEnoughActionsException;

import java.awt.GridLayout;
import java.awt.*;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.*;

import model.characters.Direction;
import model.characters.Hero;
import model.characters.Medic;
import model.characters.Zombie;
import model.collectibles.Supply;
import model.collectibles.Vaccine;
import model.world.Cell;
import model.world.CharacterCell;
import model.world.CollectibleCell;
import model.world.TrapCell;
public class Main implements  ActionListener {
	

	


//	public class main implements  ActionListener {
		private static JTextArea herostat;
		static JButton[][] buttons = new JButton[15][15];
		static int [][]mapbuttarray;
		private JButton buttonright;
	    private JButton buttonleft;
	    private JButton buttonup;
	    private JButton buttondown;
	    private static JButton buttonusespecial;
	    private JButton buttonattack;
	    private JButton buttonendturn;
	    private JButton buttoncure;
	    static Hero h;
	    static Hero clickedHero;
	 //	
		static int k=0;
		static int f=0;
		//private static JButton buttonusespecial;
		public static void main(String[] args) {
			selecthero();
			//stsrtscreen();
			 
	}
		String s;
		static int [][]selectcellarr ;
		private static JFrame frame;
		public static void fullmap() {
			 frame = new JFrame();
		    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		    frame.setSize(1600, 834);
		    frame.setLayout(new BorderLayout());
		    //frame.addKeyListener(new MyKeyListener());
		    JPanel panel = new JPanel(new GridLayout(15, 15));
		    panel.setPreferredSize(new Dimension(1342, 834));
		    frame.add(panel, BorderLayout.CENTER);
		    JPanel panel1 = new JPanel(new GridLayout(8, 1));
		    panel1.setPreferredSize(new Dimension(200, 100));
		    JButton buttonright= new JButton();
		    JButton buttonleft = new JButton();
		    JButton buttonup = new JButton();
		    JButton buttondown = new JButton();
		    JButton buttonusespecial = new JButton();
		    JButton buttonattack = new JButton();
		    JButton buttonendturn= new JButton();
		    JButton buttoncure = new JButton();
		    buttondown.setText("DOWN");
		    buttondown.setFont(new Font("Comic Sans",Font.BOLD,30));
		    buttondown.setForeground(Color.white);
		    buttondown.setBackground(Color.black);
		    buttondown.setBorder(BorderFactory.createEtchedBorder());
		    buttonup.setText("UP");
		    buttonup.setFont(new Font("Comic Sans",Font.BOLD,30));
		    buttonup.setForeground(Color.white);
		    buttonup.setBackground(Color.black);
		    buttonup.setBorder(BorderFactory.createEtchedBorder());
		    buttonright.setText("RIGHT");
		    buttonright.setFont(new Font("Comic Sans",Font.BOLD,30));
		    buttonright.setForeground(Color.white);
		    buttonright.setBackground(Color.black);
		    buttonright.setBorder(BorderFactory.createEtchedBorder());
		    buttonleft.setText("LEFT");
		    buttonleft.setFont(new Font("Comic Sans",Font.BOLD,30));
		    buttonleft.setForeground(Color.white);
		    buttonleft.setBackground(Color.black);
		    buttonleft.setBorder(BorderFactory.createEtchedBorder());
		    buttonusespecial.setText("USE SPECIAL");
		    buttonusespecial.setFont(new Font("Comic Sans",Font.BOLD,25));
		    buttonusespecial.setForeground(Color.blue);
		    buttonusespecial.setBackground(Color.black);
		    buttonusespecial.setBorder(BorderFactory.createEtchedBorder());
		    buttonattack.setText("ATTACK");
		    buttonattack.setFont(new Font("Comic Sans",Font.BOLD,30));
		    buttonattack.setForeground(Color.black);
		    buttonattack.setBackground(Color.red);
		    buttonattack.setBorder(BorderFactory.createEtchedBorder());
		    buttonendturn.setText("END TURN");
		    buttonendturn.setFont(new Font("Comic Sans",Font.BOLD,25));
		    buttonendturn.setForeground(Color.white);
		    buttonendturn.setBackground(Color.gray);
		    buttonendturn.setBorder(BorderFactory.createEtchedBorder());
		    buttoncure.setText("CURE");
		    buttoncure.setFont(new Font("Comic Sans",Font.BOLD,25));
		    buttoncure.setForeground(Color.black);
		    buttoncure.setBackground(Color.white);
//		    buttondown.setText("down");
		    frame.add(panel1, BorderLayout.WEST);
		    

		    sidepanelh();

		    


		    ImageIcon iconCell = new ImageIcon("C:\\Users\\Karim\\Downloads\\My project (2).jpg");
		    ImageIcon icontommy2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\tommy2.jpg");
		    ImageIcon iconellie2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\ellie2.jpg");
		    ImageIcon iconjoel2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\joel3.jpg");
		    ImageIcon icontess2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\tess.jpg");
		    ImageIcon iconriley2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\riley3.jpg");
		    ImageIcon iconbill2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\bill2.jpg");
		    ImageIcon icondavid2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\david2.jpg");
		    ImageIcon iconhenry2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\henryy.jpg");
		    ImageIcon iconzombie = new ImageIcon("C:\\Users\\Karim\\Downloads\\zombie.jpg");
		    ImageIcon iconvaccine = new ImageIcon("C:\\Users\\Karim\\Downloads\\vaccine.jpg");
		    ImageIcon iconsupp = new ImageIcon("C:\\Users\\Karim\\Downloads\\supply.jpg");
//		    JButton[][] buttons = new JButton[15][15];
		    ButtonClickListener buttonClickListener = new ButtonClickListener();
		    for (int i = 14; i >= 0; i--) {
		        for (int j = 0; j < 15; j++) {
		        	buttons[i][j] = new JButton();
		            String buttonName = "Button_" + i + "_" + j;
		            buttons[i][j].setName(buttonName);
		            buttons[i][j].addActionListener(buttonClickListener);
		            if (Game.map[i][j] instanceof CharacterCell) {
		                if (((CharacterCell) Game.map[i][j]).getCharacter() instanceof Hero) {
		                    // Set the appropriate icon based on the character
		                    if (k == 8)
		                    	buttons[i][j].setIcon(iconjoel2);
		                    else if (k == 1)
		                    	buttons[i][j].setIcon(iconellie2);
		                    else if (k == 2)
		                    	buttons[i][j].setIcon(icontess2);
		                    else if (k == 3)
		                    	buttons[i][j].setIcon(iconriley2);
		                    else if (k == 4)
		                    	buttons[i][j].setIcon(icontommy2);
		                    else if (k == 5)
		                    	buttons[i][j].setIcon(iconbill2);
		                    else if (k == 6)
		                    	buttons[i][j].setIcon(icondavid2);
		                    else if (k == 7)
		                    	buttons[i][j].setIcon(iconhenry2);
		                } else if (((CharacterCell) Game.map[i][j]).getCharacter() instanceof Zombie && Game.map[i][j].isVisible()==true) {
		                	buttons[i][j].setIcon(iconzombie);
		                } else {
		                	buttons[i][j].setIcon(iconCell);
		                }
		            } else if (Game.map[i][j] instanceof CollectibleCell&& Game.map[i][j].isVisible()==true) {
		                if (((CollectibleCell) Game.map[i][j]).getCollectible() instanceof Vaccine)
		                	buttons[i][j].setIcon(iconvaccine);
		                else if (((CollectibleCell) Game.map[i][j]).getCollectible() instanceof Supply)
		                	buttons[i][j].setIcon(iconsupp);}
		             else {
		            	buttons[i][j].setIcon(iconCell);
		            }

		            panel.add(buttons[i][j]);
		            selectcellarr = new int[i][j];
		            //panel.add(selectcellarr);
		        }
		    }
		   // selecttarget();
		    class ButtonClickListener implements ActionListener {


			@Override
			public void actionPerformed(ActionEvent e) {
				 Object source = e.getSource();
			        if (source == buttonright) {
			            // Code for the "buttonright" action
			        	 Direction direction = Direction.RIGHT;
	                  if (direction != null) {
	                      try {
	                    	  for(int z=0; z<15;z++) {
	                        		for(int a=0; a<15;a++) {
	                        			if (h.getLocation().equals(new Point(z, a))) {
	                        				
	                        				if(Game.map[z][a+1] instanceof TrapCell && h.getActionsAvailable()>0) {
	                        					JOptionPane.showMessageDialog(null,
		                      			                " you stepped on a trap :(");
	                        					System.out.print("stepped on trap");}}}}
	                          h.move(direction);
	                          //herostat.setText("");
	                          sidepanelh();
	                          h.getLocation();
	                          for(int z=0; z<15;z++) {
	                      		for(int a=0; a<15;a++) {
	                      			if(Game.map[z][a] instanceof CharacterCell) {
	                      				if(((CharacterCell) Game.map[z][a]).getCharacter() instanceof Zombie && Game.map[z][a].isVisible()  )
	                      					buttons[z][a].setIcon(iconzombie);
	                      			}
	                      			else if(Game.map[z][a] instanceof CollectibleCell) {
	                      				if(( (CollectibleCell) Game.map[z][a]).getCollectible() instanceof Supply && Game.map[z][a].isVisible()  )
	                      					buttons[z][a].setIcon(iconsupp);
	                      			
	                      			    else if(( (CollectibleCell) Game.map[z][a]).getCollectible() instanceof Vaccine && Game.map[z][a].isVisible()  )
	                  					buttons[z][a].setIcon(iconvaccine);}
	                  			
	                      				
	                      			if (h.getLocation().equals(new Point(z, a))) {
	                      				
	                      				
	                      				if (k == 8)
	           	                    	buttons[z][a].setIcon(iconjoel2);
	           	                    else if (k == 1)
	           	                    	buttons[z][a].setIcon(iconellie2);
	           	                    else if (k == 2)
	           	                    	buttons[z][a].setIcon(icontess2);
	           	                    else if (k == 3)
	           	                    	buttons[z][a].setIcon(iconriley2);
	           	                    else if (k == 4)
	           	                    	buttons[z][a].setIcon(icontommy2);
	           	                    else if (k == 5)
	           	                    	buttons[z][a].setIcon(iconbill2);
	           	                    else if (k == 6)
	           	                    	buttons[z][a].setIcon(icondavid2);
	           	                    else if (k == 7)
	           	                    	buttons[z][a].setIcon(iconhenry2);
	                      				buttons[z][a-1].setIcon(iconCell);
	                      			}
	                      			//up z-1 down z+1 left a+1
	                      		}
	                          }} catch (MovementException e1) {
	                      	JOptionPane.showMessageDialog(null,
	      			                "wrong movement");
	                      } catch (NotEnoughActionsException e1) {
	                      	JOptionPane.showMessageDialog(null,
	      			                "not enough actions");
	                      }
	                  }
			            System.out.println("Button Right clicked!");
			        } else if (source == buttonleft) {
			        	 Direction direction = Direction.LEFT;
		                   if (direction != null) {
		                       try {
		                    	   for(int z=0; z<15;z++) {
		                        		for(int a=0; a<15;a++) {
		                        			if(Game.map[z][a] instanceof CharacterCell) {
		                          				if(((CharacterCell) Game.map[z][a]).getCharacter() instanceof Zombie && Game.map[z][a].isVisible()  )
		                          					buttons[z][a].setIcon(iconzombie);
		                          			}
		                        			else if(Game.map[z][a] instanceof CollectibleCell) {
		                          				if(( (CollectibleCell) Game.map[z][a]).getCollectible() instanceof Supply && Game.map[z][a].isVisible()  )
		                          					buttons[z][a].setIcon(iconsupp);
		                          			
		                          			    else if(( (CollectibleCell) Game.map[z][a]).getCollectible() instanceof Vaccine && Game.map[z][a].isVisible()  )
		                      					buttons[z][a].setIcon(iconvaccine);}
		                        			if (h.getLocation().equals(new Point(z, a))) {
		                        				
		                        				if(Game.map[z][a-1] instanceof TrapCell&& h.getActionsAvailable()>0)
		                        				 {
		                        					JOptionPane.showMessageDialog(null,
			                      			                " you stepped on a trap :(");
		                        					System.out.print("stepped on trap");}}}}
		                           h.move(direction);
		                           //herostat.setText("");
		                           sidepanelh();
		                           h.getLocation();
		                           for(int m=0; m<15;m++) {
		                       		for(int y=0; y<15;y++) {
		                       			if (h.getLocation().equals(new Point(m, y))) {
		                       				if(Game.map[m][y] instanceof TrapCell)
		                      					JOptionPane.showMessageDialog(null,
		                      			                " you stepped on a trap :(");
		                       				if (k == 8)
		            	                    	buttons[m][y].setIcon(iconjoel2);
		            	                    else if (k == 1)
		            	                    	buttons[m][y].setIcon(iconellie2);
		            	                    else if (k == 2)
		            	                    	buttons[m][y].setIcon(icontess2);
		            	                    else if (k == 3)
		            	                    	buttons[m][y].setIcon(iconriley2);
		            	                    else if (k == 4)
		            	                    	buttons[m][y].setIcon(icontommy2);
		            	                    else if (k == 5)
		            	                    	buttons[m][y].setIcon(iconbill2);
		            	                    else if (k == 6)
		            	                    	buttons[m][y].setIcon(icondavid2);
		            	                    else if (k == 7)
		            	                    	buttons[m][y].setIcon(iconhenry2);
		                       				buttons[m][y+1].setIcon(iconCell);
		                       			}
		                       			//up z-1 down z+1 left a+1
		                       		}}
		                       } catch (MovementException e1) {
		                       	JOptionPane.showMessageDialog(null,
		       			                "wrong movement");
		                       } catch (NotEnoughActionsException e1) {
		                       	JOptionPane.showMessageDialog(null,
		       			                "not enough actions");
		                       }
		                   }
			        	
			            // Code for the "buttonleft" action
			            System.out.println("Button Left clicked!");
			        } else if (source == buttonup) {
			        	Direction direction = Direction.UP;
		                   if (direction != null) {
		                       try {
		                    	   for(int z=0; z<15;z++) {
		                        		for(int a=0; a<15;a++) {
		                        			if(Game.map[z][a] instanceof CharacterCell) {
		                          				if(((CharacterCell) Game.map[z][a]).getCharacter() instanceof Zombie && Game.map[z][a].isVisible()  )
		                          					buttons[z][a].setIcon(iconzombie);
		                          			}
		                        			else if(Game.map[z][a] instanceof CollectibleCell) {
		                          				if(( (CollectibleCell) Game.map[z][a]).getCollectible() instanceof Supply && Game.map[z][a].isVisible()  )
		                          					buttons[z][a].setIcon(iconsupp);
		                          			
		                          			    else if(( (CollectibleCell) Game.map[z][a]).getCollectible() instanceof Vaccine && Game.map[z][a].isVisible()  )
		                      					buttons[z][a].setIcon(iconvaccine);}
		                        			if (h.getLocation().equals(new Point(z, a))) {
		                        				
		                        				if(Game.map[z+1][a] instanceof TrapCell&& h.getActionsAvailable()>0)
		                        				 {
		                        					JOptionPane.showMessageDialog(null,
			                      			                " you stepped on a trap :(");
		                        					System.out.print("stepped on trap");}}}}
		                    	   h.move(direction);
		                    	   //herostat.setText("");
		                    	   sidepanelh();
		                    	   h.getLocation();
		                           
		                           for(int r=0; r<15;r++) {
		                       		for(int o=0; o<15;o++) {
		                       			if (h.getLocation().equals(new Point(r, o))) {
		                       				if(Game.map[r][o] instanceof TrapCell)
		                      					JOptionPane.showMessageDialog(null,
		                      			                " you stepped on a trap :(");
		                       				if (k == 8)
		            	                    	buttons[r][o].setIcon(iconjoel2);
		            	                    else if (k == 1)
		            	                    	buttons[r][o].setIcon(iconellie2);
		            	                    else if (k == 2)
		            	                    	buttons[r][o].setIcon(icontess2);
		            	                    else if (k == 3)
		            	                    	buttons[r][o].setIcon(iconriley2);
		            	                    else if (k == 4)
		            	                    	buttons[r][o].setIcon(icontommy2);
		            	                    else if (k == 5)
		            	                    	buttons[r][o].setIcon(iconbill2);
		            	                    else if (k == 6)
		            	                    	buttons[r][o].setIcon(icondavid2);
		            	                    else if (k == 7)
		            	                    	buttons[r][o].setIcon(iconhenry2);
		                       				buttons[r-1][o].setIcon(iconCell);
		                       			}
		                       			//up z-1 down z+1 left a+1
		                       		}}
		                       } catch (MovementException e1) {
		                       	JOptionPane.showMessageDialog(null,
		       			                "wrong movement");
		                       } catch (NotEnoughActionsException e1) {
		                       	JOptionPane.showMessageDialog(null,
		       			                "not enough actions");
		                       }
		                   }
			            // Code for the "buttonup" action
			        	
			            System.out.println("Button Up clicked!");
			        } else if (source == buttondown) {
			        	Direction direction = Direction.DOWN;
		                   if (direction != null) {
		                       try {
		                    	   for(int z=0; z<15;z++) {
		                        		for(int a=0; a<15;a++) {
		                        			if(Game.map[z][a] instanceof CharacterCell) {
		                          				if(((CharacterCell) Game.map[z][a]).getCharacter() instanceof Zombie && Game.map[z][a].isVisible()  )
		                          					buttons[z][a].setIcon(iconzombie);
		                          				else if(Game.map[z][a] instanceof CollectibleCell) {
		                              				if(( (CollectibleCell) Game.map[z][a]).getCollectible() instanceof Supply && Game.map[z][a].isVisible()  )
		                              					buttons[z][a].setIcon(iconsupp);
		                              			
		                              			    else if(( (CollectibleCell) Game.map[z][a]).getCollectible() instanceof Vaccine && Game.map[z][a].isVisible()  )
		                          					buttons[z][a].setIcon(iconvaccine);}
		                          			}
		                        			if (h.getLocation().equals(new Point(z, a))) {
		                        				
		                        				if(Game.map[z-1][a] instanceof TrapCell&& h.getActionsAvailable()>0){
		                        				 
		                        					JOptionPane.showMessageDialog(null,
			                      			                " you stepped on a trap :(");
		                        					System.out.print("stepped on trap");}}}}
		                           h.move(direction);
		                           //herostat.setText("");
		                           sidepanelh();
		                           h.getLocation();
		                           for(int t=0; t<15;t++) {
		                       		for(int n=0; n<15;n++) {
		                       			if (h.getLocation().equals(new Point(t, n))) {
		                       				if(Game.map[t][n] instanceof TrapCell)
		                      					JOptionPane.showMessageDialog(null,
		                      			                " you stepped on a trap :(");
		                       				if (k == 8)
		            	                    	buttons[t][n].setIcon(iconjoel2);
		            	                    else if (k == 1)
		            	                    	buttons[t][n].setIcon(iconellie2);
		            	                    else if (k == 2)
		            	                    	buttons[t][n].setIcon(icontess2);
		            	                    else if (k == 3)
		            	                    	buttons[t][n].setIcon(iconriley2);
		            	                    else if (k == 4)
		            	                    	buttons[t][n].setIcon(icontommy2);
		            	                    else if (k == 5)
		            	                    	buttons[t][n].setIcon(iconbill2);
		            	                    else if (k == 6)
		            	                    	buttons[t][n].setIcon(icondavid2);
		            	                    else if (k == 7)
		            	                    	buttons[t][n].setIcon(iconhenry2);
		                       				buttons[t+1][n].setIcon(iconCell);
		                       			}
		                       			//up z-1 down z+1 left a+1
		                       		}}
		                       } catch (MovementException e1) {
		                       	JOptionPane.showMessageDialog(null,
		       			                "wrong movement");
		                       } catch (NotEnoughActionsException e1) {
		                       	JOptionPane.showMessageDialog(null,
		       			                "not enough actions");
		                       }
		                   }
			            // Code for the "buttondown" action
			            System.out.println("Button Down clicked!");
			        } else if (source == buttonusespecial) {
			        	
	                		
			        	if (h instanceof Medic && !h.getSupplyInventory().isEmpty()) {
			                selecthero2(); 
			            }

			        	else
			        		try {
			                    h.useSpecial();
			                    for(int z=0; z<15;z++) {
	                        		for(int a=0; a<15;a++) {
	                        			if(Game.map[z][a] instanceof CharacterCell) {
	                          				if(((CharacterCell) Game.map[z][a]).getCharacter() instanceof Zombie && Game.map[z][a].isVisible()  )
	                          					buttons[z][a].setIcon(iconzombie);
	                        			}
	                          				else if(Game.map[z][a] instanceof CollectibleCell) {
	                              				if(( (CollectibleCell) Game.map[z][a]).getCollectible() instanceof Supply && Game.map[z][a].isVisible()  )
	                              					buttons[z][a].setIcon(iconsupp);
	                              			
	                              			    else if(( (CollectibleCell) Game.map[z][a]).getCollectible() instanceof Vaccine && Game.map[z][a].isVisible()  )
	                          					buttons[z][a].setIcon(iconvaccine);}}}
			                    sidepanelh();
			                    if(Game.checkWin()==true)
			                    	JOptionPane.showMessageDialog(null, "you won");
			                    else if(Game.checkGameOver()==true)
			                    	 JOptionPane.showMessageDialog(null, "you lost :(");
			                } catch (NoAvailableResourcesException | InvalidTargetException ex) {
			                    if (h.getSupplyInventory().isEmpty())
			                        JOptionPane.showMessageDialog(null, "Supply inventory is empty");
			                    else
			                        JOptionPane.showMessageDialog(null, "Invalid target");
			                    ex.printStackTrace();
			                }
			        		
	                        			
			        	
	                
			        } else if (source == buttonattack) {
			        	
			        	//selecttarget();
	                   		
			            try {
							h.attack();
							sidepanelh();
							if(h.getTarget().getCurrentHp()<=1) {
								for(int t=0; t<15;t++) {
		                       		for(int n=0; n<15;n++) {
		                       			if (h.getTarget().getLocation().equals(new Point(t, n)))
		                       				buttons[t][n].setIcon(iconCell);
		                       			if(Game.map[t][n] instanceof CharacterCell && Game.map[t][n].isVisible() ) {
		                       			if (((CharacterCell) Game.map[t][n]).getCharacter() instanceof Zombie) 
		            	                	buttons[t][n].setIcon(iconzombie);	
		                       		}}}
							}
//							for (int i = 14; i >= 0; i--) {
//						        for (int j = 0; j < 15; j++) {
//						        	if(Game.map[i][j] instanceof CharacterCell ) {
//	                       			if (((CharacterCell) Game.map[i][j]).getCharacter() instanceof Zombie) 
//	            	                	buttons[i][j].setIcon(iconzombie);
//	                       		}}
//							}
							if(h.getCurrentHp()<=0) {
								for(int r=0; r<15;r++) {
		                       		for(int o=0; o<15;o++) {
		                       			if (h.getLocation().equals(new Point(r, o)))
		                       				buttons[r][o].setIcon(iconCell);
		                       		}
							}}
							
							sidepanelh();
							if(Game.checkWin()==true)
		                    	JOptionPane.showMessageDialog(null, "you won!!!!!!!!!!!!!!!");
		                    else if(Game.checkGameOver()==true)
		                    	 JOptionPane.showMessageDialog(null, "you lost :(");
						} catch (NotEnoughActionsException | InvalidTargetException e1) {
							if(h.getActionsAvailable()<=0) {
								JOptionPane.showMessageDialog(null,
		    			                "not enough actions");}
							else
							JOptionPane.showMessageDialog(null,
	    			                "Invalid target");	
							
							e1.printStackTrace();
						}
			            System.out.println("Button Attack clicked!");
			        } else if (source == buttonendturn) {
			            try {
			            	sidepanelh();
			            	ArrayList<Point> hloc = new ArrayList<>();
			            	for(int i=0; i<Game.heroes.size(); i++) {
			            		hloc.add( new Point(Game.heroes.get(i).getLocation()));
			            	}
							Game.endTurn();
							//herostat.setText("");
							sidepanelh();
							for(int i=0; i<hloc.size(); i++) {
								if((((CharacterCell)Game.map[(int) hloc.get(i).getX()][(int) hloc.get(i).getY()]).getCharacter())==null) {
									sidepanelh();
									for(int m=0; m<15;m++) {
			                       		for(int y=0; y<15;y++) {
			                       			if(hloc.get(i).equals(new Point(m, y)))
			                       				buttons[m][y].setIcon(iconCell);
			                       				
								}
									
							}
								}}
							ArrayList<Point> zloc = new ArrayList<>();
			            	for(int i=0; i<Game.zombies.size(); i++) {
			            		zloc.add( new Point(Game.zombies.get(i).getLocation()));
			            	}
							
							//herostat.setText("");
							
							for(int i=0; i<zloc.size(); i++) {
								if((((CharacterCell)Game.map[(int) zloc.get(i).getX()][(int) zloc.get(i).getY()]).getCharacter())==null) {
									sidepanelh();
									for(int m=0; m<15;m++) {
			                       		for(int y=0; y<15;y++) {
			                       			if(zloc.get(i).equals(new Point(m, y)))
			                       				buttons[m][y].setIcon(iconCell);
			                       				
								}
									
							}
								
			                       				
								
									
							}
								}
							
							for(int t=0; t<15;t++) {
	                       		for(int n=0; n<15;n++) {
	                       			if(Game.map[t][n] instanceof CharacterCell ) {
	                       			if (((CharacterCell) Game.map[t][n]).getCharacter() instanceof Zombie && Game.map[t][n].isVisible()) 
	            	                	buttons[t][n].setIcon(iconzombie);
	                       		}}
	                       		}
							sidepanelh();
							if(Game.checkWin()==true)
		                    	JOptionPane.showMessageDialog(null, "you won!!!!!!!!!!!!!!");
		                    else if(Game.checkGameOver()==true)
		                    	 JOptionPane.showMessageDialog(null, "you lost :(");
						} catch (NotEnoughActionsException | InvalidTargetException e1) {
							// TODO Auto-generated catch block
							if(h.getActionsAvailable()<=0) {
								JOptionPane.showMessageDialog(null,
		    			                "not enough actions");}
							else
							JOptionPane.showMessageDialog(null,
	    			                "Invalid target");	
							e1.printStackTrace();
						}
			            System.out.println("Button end turn clicked!");
			            
			        }
			        else if (source == buttoncure) {
			        	try {
							h.cure();
							//selectherocure();
								for(int t=0; t<15;t++) {
		                       		for(int n=0; n<15;n++) {
		                       			if(Game.map[t][n] instanceof CharacterCell ) {
		                       			if (h.getTarget().getLocation().equals(new Point(t, n))) {
		                       				if(((CharacterCell) Game.map[t][n]).getCharacter().getMaxHp()== 140)
		                       				buttons[t][n].setIcon(iconjoel2);
		                       				if(((CharacterCell) Game.map[t][n]).getCharacter().getMaxHp()== 110)
			                       				buttons[t][n].setIcon(iconellie2);
		                       				if(((CharacterCell) Game.map[t][n]).getCharacter().getMaxHp()== 80)
			                       				buttons[t][n].setIcon(icontess2);
		                       				if(((CharacterCell) Game.map[t][n]).getCharacter().getMaxHp()== 90)
			                       				buttons[t][n].setIcon(iconriley2);
		                       				if(((CharacterCell) Game.map[t][n]).getCharacter().getMaxHp()== 95)
			                       				buttons[t][n].setIcon(icontommy2);
		                       				if(((CharacterCell) Game.map[t][n]).getCharacter().getMaxHp()== 100)
			                       				buttons[t][n].setIcon(iconbill2);
		                       				if(((CharacterCell) Game.map[t][n]).getCharacter().getMaxHp()== 150)
			                       				buttons[t][n].setIcon(icondavid2);
		                       				if(((CharacterCell) Game.map[t][n]).getCharacter().getMaxHp()== 105)
			                       				buttons[t][n].setIcon(iconhenry2);
		                       			}
		                       		}}}
								sidepanelh();
								if(Game.checkWin()==true)
			                    	JOptionPane.showMessageDialog(null, "you won!!!!!!!!!");
			                    else if(Game.checkGameOver()==true)
			                    	 JOptionPane.showMessageDialog(null, "you lost :(");
						} catch (NoAvailableResourcesException | InvalidTargetException | NotEnoughActionsException e1) {
							if(h.getActionsAvailable()<=0)
								JOptionPane.showMessageDialog(null,
		    			                "not enough actions");
							else if(h.getVaccineInventory().get(0)==null)
								JOptionPane.showMessageDialog(null,
		    			                "no vaccines in inventory");
							else
								JOptionPane.showMessageDialog(null,
		    			                "Invalid target");
								
							e1.printStackTrace();
						}
			        }
			        	
			    }}
			 ButtonClickListener listener = new ButtonClickListener();
			 buttonright.addActionListener(listener);
			    buttonleft.addActionListener(listener);
			    buttonup.addActionListener(listener);
			    buttondown.addActionListener(listener);
			    buttonusespecial.addActionListener(listener);
			    buttonattack.addActionListener(listener);
			    buttonendturn.addActionListener(listener);
			    buttoncure.addActionListener(listener);
			

		    
		    panel1.add(buttondown);
		    panel1.add(buttonup);
		    panel1.add(buttonleft);
		    panel1.add(buttonright);
		    panel1.add(buttonusespecial);
		    panel1.add(buttonattack);
		    panel1.add(buttonendturn);
		    panel1.add(buttoncure);
		    
		    frame.add(panel1, BorderLayout.WEST);
		    frame.setVisible(true);
		    Direction direction=null;

		    
		    
		    }
		



		
	static ArrayList<JButton> btnsarray;
	JButton button = null;
	public static void selecthero()  {
		
		ImageIcon icontommy = new ImageIcon("C:\\Users\\Karim\\Downloads\\tommy.jpeg");
		ImageIcon iconellie = new ImageIcon("C:\\Users\\Karim\\Downloads\\ellie.jpeg");
		ImageIcon iconjoel = new ImageIcon("C:\\Users\\Karim\\Downloads\\joel.jpeg");
		ImageIcon icontess = new ImageIcon("C:\\Users\\Karim\\Downloads\\tess.jpeg");
		ImageIcon iconriley = new ImageIcon("C:\\Users\\Karim\\Downloads\\riley.jpeg");
		ImageIcon iconbill = new ImageIcon("C:\\Users\\Karim\\Downloads\\bill.jpeg");
		ImageIcon icondavid = new ImageIcon("C:\\Users\\Karim\\Downloads\\david.jpeg");
		ImageIcon iconhenry = new ImageIcon("C:\\Users\\Karim\\Downloads\\henry.jpeg");
		ImageIcon iconCell = new ImageIcon("C:\\Users\\Karim\\Downloads\\My project (2).jpg");
	    ImageIcon icontommy2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\tommy2.jpeg");
		ImageIcon iconellie2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\ellie2.jpeg");
		ImageIcon iconjoel2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\joel3.jpeg");
		ImageIcon icontess2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\tess2.jpeg");
		ImageIcon iconriley2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\riley2.jpeg");
		ImageIcon iconbill2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\bill2.jpeg");
		ImageIcon icondavid2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\david2.jpeg");
		ImageIcon iconhenry2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\henry2.jpeg");
	    ImageIcon iconHero = new ImageIcon("C:\\Users\\Karim\\Downloads\\My project (3).jpg");
	    
		JFrame frame = new JFrame();
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setSize(500, 500);
	    frame.setBounds(0, 0, 1600, 834);
	    frame.setLayout(new GridLayout(3, 0));
	    btnsarray = new ArrayList<>();
	    for (int i = 0; i<9; i++) {
	    	 JButton button = new JButton();
	    	 button.setBackground(Color.black);
	    	 frame.add(button);
	    	 frame.setVisible(true);
	    	// button.addActionListener();
	    	 if(i==0)
	    	 button.setIcon(iconjoel);
	    	 if(i==1)
	        	 button.setIcon(iconellie);
	    	 if(i==2)
	        	 button.setIcon(icontess);
	    	 if(i==3)
	        	 button.setIcon(iconriley);
	    	 if(i==4)
	        	 button.setIcon(icontommy);
	    	 if(i==5)
	        	 button.setIcon(iconbill);
	    	 if(i==6)
	        	 button.setIcon(icondavid);
	    	 if(i==7)
	        	 button.setIcon(iconhenry);
	    	 if(i==8) {
	    		 button.setText("SELECT HERO");
		     button.setForeground(Color.white);
		     button.setFont(new Font("Comic Sans",Font.BOLD,30));}
	    	 btnsarray.add(button);
	    		 
	    }
	    
	    for (JButton button : btnsarray) {
	        button.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                JButton button = (JButton) e.getSource();
	                int bIndex = btnsarray.indexOf(button);
	                if(bIndex == 0)
	              		 k=8;
	              	else if(bIndex == 1)
	              		 k=1;
	              	else if(bIndex == 2)
	              		 k=2;
	              	else if(bIndex == 3)
	              		 k=3;
	              	else if(bIndex == 4)
	              		 k=4;
	              	else if(bIndex == 5)
	              		 k=5;
	              	else if(bIndex == 6)
	              		 k=6;
	              	else if(bIndex == 7)
	              		 k=7;
	                try {
						Game.loadHeroes("Heroes.csv");
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						JOptionPane.showMessageDialog(null,
				                "input output exception");
						e1.printStackTrace();
					}
	                 h = Game.availableHeroes.get(bIndex);
	                
	                Game.startGame( h);
	                
	                JOptionPane.showMessageDialog(null,
			                "hero has been selected");
	                System.out.print(Game.heroes);
	                fullmap();
	            }
	        });}
	}


	public void actionPerformed(ActionEvent e) {

		// get the JButton that was clicked
		JButton button = (JButton) e.getSource();
		// get its index within the ArrayList of buttons
		int bIndex = btnsarray.indexOf(button);


	}


	static class ButtonClickListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			Object source = e.getSource();
			for(int c=0; c<15;c++) {
		  		for(int s=0; s<15;s++) {
		  			if (source == buttons[c][s]) {
		  				if(Game.map[c][s] instanceof CharacterCell ) {
		  				if ((((CharacterCell) Game.map[c][s]).getCharacter()) instanceof Zombie) {
		  				System.out.print("target selected");
		  				h.setTarget(((CharacterCell) Game.map[c][s]).getCharacter());
		  				}
		  				else if((((CharacterCell) Game.map[c][s]).getCharacter()) instanceof Hero) {
		  					 h = (Hero) (((CharacterCell) Game.map[c][s]).getCharacter()) ;
		  				}
		  					if(h.getMaxHp()== 140)
		  						k=8;
		  					if(h.getMaxHp()== 110)
		  						k=1;
		  					if(h.getMaxHp()== 80)
		  						k=2;
		  					if(h.getMaxHp()== 90)
		  						k=3;
		  					if(h.getMaxHp()== 95)
		  						k=4;
		  					if(h.getMaxHp()== 100)
		  						k=5;
		  					if(h.getMaxHp()== 150)
		  						k=6;
		  					if(h.getMaxHp()== 105)
		  						k=7;
		  			}}
		  		
		  			
		  			}
		}}
			
		}
	public static void selectherocure()  {
		
		ImageIcon icontommy = new ImageIcon("C:\\Users\\Karim\\Downloads\\tommy.jpeg");
		ImageIcon iconellie = new ImageIcon("C:\\Users\\Karim\\Downloads\\ellie.jpeg");
		ImageIcon iconjoel = new ImageIcon("C:\\Users\\Karim\\Downloads\\joel.jpeg");
		ImageIcon icontess = new ImageIcon("C:\\Users\\Karim\\Downloads\\tess.jpeg");
		ImageIcon iconriley = new ImageIcon("C:\\Users\\Karim\\Downloads\\riley.jpeg");
		ImageIcon iconbill = new ImageIcon("C:\\Users\\Karim\\Downloads\\bill.jpeg");
		ImageIcon icondavid = new ImageIcon("C:\\Users\\Karim\\Downloads\\david.jpeg");
		ImageIcon iconhenry = new ImageIcon("C:\\Users\\Karim\\Downloads\\henry.jpeg");
		ImageIcon iconCell = new ImageIcon("C:\\Users\\Karim\\Downloads\\My project (2).jpg");
	    ImageIcon icontommy2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\tommy2.jpeg");
		ImageIcon iconellie2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\ellie2.jpeg");
		ImageIcon iconjoel2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\joel3.jpeg");
		ImageIcon icontess2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\tess2.jpeg");
		ImageIcon iconriley2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\riley2.jpeg");
		ImageIcon iconbill2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\bill2.jpeg");
		ImageIcon icondavid2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\david2.jpeg");
		ImageIcon iconhenry2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\henry2.jpeg");
	    ImageIcon iconHero = new ImageIcon("C:\\Users\\Karim\\Downloads\\My project (3).jpg");
	    
		JFrame frame = new JFrame();
	    //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setSize(500, 500);
	    frame.setBounds(0, 0, 1300, 700);
	    frame.setLayout(new GridLayout(3, 0));
	    btnsarray = new ArrayList<>();
	    for (int i = 0; i<Game.availableHeroes.size(); i++) {
	    	 JButton button2 = new JButton();
	    	 button2.setBackground(Color.black);
	    	 frame.add(button2);
	    	 frame.setVisible(true);
	    	// button.addActionListener();
	    	 if(Game.availableHeroes.get(i).getMaxHp()== 140)
	        	 button2.setIcon(iconjoel);
	        	 if(Game.availableHeroes.get(i).getMaxHp()== 110)
	            	 button2.setIcon(iconellie);
	        	 if(Game.availableHeroes.get(i).getMaxHp()== 80)
	            	 button2.setIcon(icontess);
	        	 if(Game.availableHeroes.get(i).getMaxHp()== 90)
	            	 button2.setIcon(iconriley);
	        	 if(Game.availableHeroes.get(i).getMaxHp()== 95)
	            	 button2.setIcon(icontommy);
	        	 if(Game.availableHeroes.get(i).getMaxHp()== 100)
	            	 button2.setIcon(iconbill);
	        	 if(Game.availableHeroes.get(i).getMaxHp()== 150)
	            	 button2.setIcon(icondavid);
	        	 if(Game.availableHeroes.get(i).getMaxHp()== 105)
	            	 button2.setIcon(iconhenry);
	        	 
	        	 
	    	
		     button2.setForeground(Color.white);
		     button2.setFont(new Font("Comic Sans",Font.BOLD,30));
	    	 
			btnsarray.add(button2);}
	    		 

	    
	    for (JButton button2 : btnsarray) {
	        button2.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                JButton button = (JButton) e.getSource();
	                int b = -1; // Default value for b

	                // Find the index of the selected button
	                for (int i = 0; i < btnsarray.size(); i++) {
	                    if (button == btnsarray.get(i)) {
	                        b = i;
	                        break;
	                    }
	                }

	                // Use the value of b to determine the selected hero
	                if (b != -1) {
	                    switch (Game.availableHeroes.get(b).getMaxHp()) {
	                        case 140:
	                            f=1;
	                            break;
	                        case 110:
	                            f=2;
	                            break;
	                        case 80:
	                            f=3;
	                            break;
	                        case 90 :
	                        	f=4;
	                        	break;
	                        case 95:
	                            f=5;
	                            break;
	                        case 100:
	                            f=6;
	                            break; 
	                        case 150:
	                            f=7;
	                            break;
	                        case 105:
	                            f=8;
	                            break;   
	                        // Add cases for other heroes
	                    }
	                }
	            }
	        });
	    }

	}
	//static String sidehero = "";
	public static void sidepanelh() {
		String sidehero = "";
	for (int i = 0; i < Game.heroes.size(); i++) {
	    sidehero += "Hero Name: " + Game.heroes.get(i).getName() + "\n";
	    sidehero += "Current Hp: " + Integer.toString(Game.heroes.get(i).getCurrentHp()) + "\n";
	    sidehero += "Attack Damage: " + Integer.toString(Game.heroes.get(i).getAttackDmg()) + "\n";
	    sidehero += "Max Actions: " + Integer.toString(Game.heroes.get(i).getMaxActions()) + "\n";
	    if(!Game.heroes.get(i).getVaccineInventory().isEmpty())
	    sidehero += "Vaccine inventory: " +Integer.toString (Game.heroes.get(i).getVaccineInventory().size()) + "\n";
	    if(!Game.heroes.get(i).getSupplyInventory().isEmpty())
	    sidehero += "Supply inventory: " + Integer.toString(Game.heroes.get(i).getSupplyInventory().size()) + "\n";
	    sidehero += "Actions available: " + Integer.toString(Game.heroes.get(i).getActionsAvailable()) + "\n";
	    sidehero += "Hero Type:";
		 if(Game.heroes.get(i).getMaxHp()==140)
			    sidehero += "Fighter\n";
		 else if(Game.heroes.get(i).getMaxHp()==110)
			    sidehero += "Medic\n";
		     else if(Game.heroes.get(i).getMaxHp()==80)
			    sidehero += "Explorer\n";
		     else if(Game.heroes.get(i).getMaxHp()==90)
		    	sidehero += "Explorer\n";
		     else if(Game.heroes.get(i).getMaxHp()==95)
		    	sidehero += "Explorer\n";
		     else if(Game.heroes.get(i).getMaxHp()==100)
		    	sidehero += "Medic\n";
		     else if(Game.heroes.get(i).getMaxHp()==150)
			    sidehero += "Fighter\n";
		     else if(Game.heroes.get(i).getMaxHp()==105)
			    sidehero += "Medic\n";
	    sidehero += "--------------------\n";
	}
	 herostat = new JTextArea("Unlocked heroes stats:\n" + sidehero);
	herostat.setEditable(false);
	JScrollPane scrollPane = new JScrollPane(herostat);
	scrollPane.setPreferredSize(new Dimension(150, 834));
	frame.add(scrollPane, BorderLayout.EAST);

	}	


	public static void selecthero2() {
	    ImageIcon icontommy = new ImageIcon("C:\\Users\\Karim\\Downloads\\tommy.jpeg");
	    ImageIcon iconellie = new ImageIcon("C:\\Users\\Karim\\Downloads\\ellie.jpeg");
	    ImageIcon iconjoel = new ImageIcon("C:\\Users\\Karim\\Downloads\\joel.jpeg");
	    ImageIcon icontess = new ImageIcon("C:\\Users\\Karim\\Downloads\\tess.jpeg");
	    ImageIcon iconriley = new ImageIcon("C:\\Users\\Karim\\Downloads\\riley.jpeg");
	    ImageIcon iconbill = new ImageIcon("C:\\Users\\Karim\\Downloads\\bill.jpeg");
	    ImageIcon icondavid = new ImageIcon("C:\\Users\\Karim\\Downloads\\david.jpeg");
	    ImageIcon iconhenry = new ImageIcon("C:\\Users\\Karim\\Downloads\\henry.jpeg");
	    ImageIcon iconCell = new ImageIcon("C:\\Users\\Karim\\Downloads\\My project (2).jpg");
	    ImageIcon icontommy2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\tommy2.jpeg");
	    ImageIcon iconellie2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\ellie2.jpeg");
	    ImageIcon iconjoel2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\joel3.jpeg");
	    ImageIcon icontess2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\tess2.jpeg");
	    ImageIcon iconriley2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\riley2.jpeg");
	    ImageIcon iconbill2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\bill2.jpeg");
	    ImageIcon icondavid2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\david2.jpeg");
	    ImageIcon iconhenry2 = new ImageIcon("C:\\Users\\Karim\\Downloads\\henry2.jpeg");
	    ImageIcon iconHero = new ImageIcon("C:\\Users\\Karim\\Downloads\\My project (3).jpg");

	    JFrame frame = new JFrame();
	    frame.setSize(500, 500);
	    frame.setBounds(0, 0, 1300, 700);
//	    button[i].setBackground(Color.black);
	    frame.setLayout(new GridLayout(3, 0));
	    ArrayList<JButton> btnarray = new ArrayList<>();
	    JButton[] button = new JButton[Game.heroes.size()];
	    for (int i = 0; i < Game.heroes.size(); i++) {
	    	 button[i] = new JButton();
	    	 button[i].setBackground(Color.black);
	        String buttonName = "Button_" + i ;
	        button[i].setName(buttonName);
	        frame.add(button[i]);
	        frame.setVisible(true);

	        if (Game.heroes.get(i).getMaxHp() == 140)
	            button[i].setIcon(iconjoel);
	        else if (Game.heroes.get(i).getMaxHp() == 110)
	            button[i].setIcon(iconellie);
	        else if (Game.heroes.get(i).getMaxHp() == 80)
	            button[i].setIcon(icontess);
	        else if (Game.heroes.get(i).getMaxHp() == 90)
	            button[i].setIcon(iconriley);
	        else if (Game.heroes.get(i).getMaxHp() == 95)
	            button[i].setIcon(icontommy);
	        else if (Game.heroes.get(i).getMaxHp() == 100)
	            button[i].setIcon(iconbill);
	        else if (Game.heroes.get(i).getMaxHp() == 150)
	            button[i].setIcon(icondavid);
	        else if (Game.heroes.get(i).getMaxHp() == 105)
	            button[i].setIcon(iconhenry);

	        btnarray.add(button[i]);
	    }

	   
	        
	           
	        
	    
	   
	 
	    //JButton[] button = new JButton[btnarray.size()];
	    for (int f = 0; f < btnarray.size(); f++) {
	        button[f] = btnarray.get(f);
	        final int index = f;
	        button[f].addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                if (button[index].getIcon() == iconjoel) {
	                    for (int i = 14; i >= 0; i--) {
	                        for (int j = 0; j < 15; j++) {
	                            if (Game.map[i][j] instanceof CharacterCell) {
	                            	if(((CharacterCell) Game.map[i][j]).getCharacter()!=null) {
	                                if (((CharacterCell) Game.map[i][j]).getCharacter().getMaxHp() == 140) {
	                                    h.setTarget(((CharacterCell) Game.map[i][j]).getCharacter());
	                                    JOptionPane.showMessageDialog(frame, "Hero has been selected", "Message", JOptionPane.INFORMATION_MESSAGE);
	                                    System.out.println(h.getTarget().getName());
	                                    try {
	                                        h.useSpecial();
	                                        sidepanelh();
	                                    } catch (NoAvailableResourcesException | InvalidTargetException ex) {
	                                        if (h.getSupplyInventory().isEmpty())
	                                            JOptionPane.showMessageDialog(null, "Supply inventory is empty");
	                                        else
	                                            JOptionPane.showMessageDialog(null, "Invalid target");
	                                        ex.printStackTrace();}
	                                }
	                            }
	                           }
	                        }
	                    }
	                }
	                else if (button[index].getIcon() == iconellie) {
	                    for (int i = 14; i >= 0; i--) {
	                        for (int j = 0; j < 15; j++) {
	                            if (Game.map[i][j] instanceof CharacterCell) {
	                            	if(((CharacterCell) Game.map[i][j]).getCharacter()!=null) {
	                                if (((CharacterCell) Game.map[i][j]).getCharacter().getMaxHp() == 110) {
	                                    h.setTarget(((CharacterCell) Game.map[i][j]).getCharacter());
	                                    JOptionPane.showMessageDialog(frame, "Hero has been selected", "Message", JOptionPane.INFORMATION_MESSAGE);
	                                    System.out.println(h.getTarget().getName());
	                                    try {
	                                        h.useSpecial();
	                                        sidepanelh();
	                                    } catch (NoAvailableResourcesException | InvalidTargetException ex) {
	                                        if (h.getSupplyInventory().isEmpty())
	                                            JOptionPane.showMessageDialog(null, "Supply inventory is empty");
	                                        else
	                                            JOptionPane.showMessageDialog(null, "Invalid target");
	                                        ex.printStackTrace();}
	                                }
	                             }
	                          }
	                       }
	                    }
	                }
	                else if (button[index].getIcon() == icontess) {
	                    for (int i = 14; i >= 0; i--) {
	                        for (int j = 0; j < 15; j++) {
	                            if (Game.map[i][j] instanceof CharacterCell) {
	                            	if(((CharacterCell) Game.map[i][j]).getCharacter()!=null) {
	                                if (((CharacterCell) Game.map[i][j]).getCharacter().getMaxHp() == 80) {
	                                    h.setTarget(((CharacterCell) Game.map[i][j]).getCharacter());
	                                    JOptionPane.showMessageDialog(frame, "Hero has been selected", "Message", JOptionPane.INFORMATION_MESSAGE);
	                                    System.out.println(h.getTarget().getName());
	                                    try {
	                                        h.useSpecial();
	                                        sidepanelh();
	                                    } catch (NoAvailableResourcesException | InvalidTargetException ex) {
	                                        if (h.getSupplyInventory().isEmpty())
	                                            JOptionPane.showMessageDialog(null, "Supply inventory is empty");
	                                        else
	                                            JOptionPane.showMessageDialog(null, "Invalid target");
	                                        ex.printStackTrace();}
	                                }
	                            }
	                            }
	                        }
	                    }
	                }
	                else if (button[index].getIcon() == iconriley) {
	                    for (int i = 14; i >= 0; i--) {
	                        for (int j = 0; j < 15; j++) {
	                            if (Game.map[i][j] instanceof CharacterCell) {
	                            	if(((CharacterCell) Game.map[i][j]).getCharacter()!=null) {
	                                if (((CharacterCell) Game.map[i][j]).getCharacter().getMaxHp() == 90) {
	                                    h.setTarget(((CharacterCell) Game.map[i][j]).getCharacter());
	                                    JOptionPane.showMessageDialog(frame, "Hero has been selected", "Message", JOptionPane.INFORMATION_MESSAGE);
	                                    System.out.println(h.getTarget().getName());
	                                    try {
	                                        h.useSpecial();
	                                        sidepanelh();
	                                    } catch (NoAvailableResourcesException | InvalidTargetException ex) {
	                                        if (h.getSupplyInventory().isEmpty())
	                                            JOptionPane.showMessageDialog(null, "Supply inventory is empty");
	                                        else
	                                            JOptionPane.showMessageDialog(null, "Invalid target");
	                                        ex.printStackTrace();}
	                                }
	                            }
	                            }
	                        }
	                    }
	                }
	                else if (button[index].getIcon() == icontommy) {
	                    for (int i = 14; i >= 0; i--) {
	                        for (int j = 0; j < 15; j++) {
	                            if (Game.map[i][j] instanceof CharacterCell) {
	                            	if(((CharacterCell) Game.map[i][j]).getCharacter()!=null) {
	                                if (((CharacterCell) Game.map[i][j]).getCharacter().getMaxHp() == 95) {
	                                    h.setTarget(((CharacterCell) Game.map[i][j]).getCharacter());
	                                    JOptionPane.showMessageDialog(frame, "Hero has been selected", "Message", JOptionPane.INFORMATION_MESSAGE);
	                                    System.out.println(h.getTarget().getName());
	                                    try {
	                                        h.useSpecial();
	                                        sidepanelh();
	                                    } catch (NoAvailableResourcesException | InvalidTargetException ex) {
	                                        if (h.getSupplyInventory().isEmpty())
	                                            JOptionPane.showMessageDialog(null, "Supply inventory is empty");
	                                        else
	                                            JOptionPane.showMessageDialog(null, "Invalid target");
	                                        ex.printStackTrace();}
	                                }
	                            }
	                            }
	                        }
	                    }
	                }
	                else if (button[index].getIcon() == iconbill) {
	                    for (int i = 14; i >= 0; i--) {
	                        for (int j = 0; j < 15; j++) {
	                            if (Game.map[i][j] instanceof CharacterCell) {
	                            	if(((CharacterCell) Game.map[i][j]).getCharacter()!=null) {
	                                if (((CharacterCell) Game.map[i][j]).getCharacter().getMaxHp() == 100) {
	                                    h.setTarget(((CharacterCell) Game.map[i][j]).getCharacter());
	                                    JOptionPane.showMessageDialog(frame, "Hero has been selected", "Message", JOptionPane.INFORMATION_MESSAGE);
	                                    System.out.println(h.getTarget().getName());
	                                    try {
	                                        h.useSpecial();
	                                        sidepanelh();
	                                    } catch (NoAvailableResourcesException | InvalidTargetException ex) {
	                                        if (h.getSupplyInventory().isEmpty())
	                                            JOptionPane.showMessageDialog(null, "Supply inventory is empty");
	                                        else
	                                            JOptionPane.showMessageDialog(null, "Invalid target");
	                                        ex.printStackTrace();}
	                                }
	                            }
	                            }
	                        }
	                    }
	                }
	                else if (button[index].getIcon() == icondavid) {
	                    for (int i = 14; i >= 0; i--) {
	                        for (int j = 0; j < 15; j++) {
	                            if (Game.map[i][j] instanceof CharacterCell) {
	                            	if(((CharacterCell) Game.map[i][j]).getCharacter()!=null) {
	                                if (((CharacterCell) Game.map[i][j]).getCharacter().getMaxHp() == 150) {
	                                    h.setTarget(((CharacterCell) Game.map[i][j]).getCharacter());
	                                    JOptionPane.showMessageDialog(frame, "Hero has been selected", "Message", JOptionPane.INFORMATION_MESSAGE);
	                                    System.out.println(h.getTarget().getName());
	                                    try {
	                                        h.useSpecial();
	                                        sidepanelh();
	                                    } catch (NoAvailableResourcesException | InvalidTargetException ex) {
	                                        if (h.getSupplyInventory().isEmpty())
	                                            JOptionPane.showMessageDialog(null, "Supply inventory is empty");
	                                        else
	                                            JOptionPane.showMessageDialog(null, "Invalid target");
	                                        ex.printStackTrace();}
	                                }
	                            }
	                            }
	                        }
	                    }
	                }
	                else if (button[index].getIcon() == iconhenry) {
	                    for (int i = 14; i >= 0; i--) {
	                        for (int j = 0; j < 15; j++) {
	                            if (Game.map[i][j] instanceof CharacterCell) {
	                            	if(((CharacterCell) Game.map[i][j]).getCharacter()!=null) {
	                                if (((CharacterCell) Game.map[i][j]).getCharacter().getMaxHp() == 105) {
	                                    h.setTarget(((CharacterCell) Game.map[i][j]).getCharacter());
	                                    JOptionPane.showMessageDialog(frame, "Hero has been selected", "Message", JOptionPane.INFORMATION_MESSAGE);
	                                    System.out.println(h.getTarget().getName());
	                                    try {
	                                        h.useSpecial();
	                                        sidepanelh();
	                                        if(Game.checkWin()==true)
	        			                    	JOptionPane.showMessageDialog(null, "you won!!!!!!!!");
	        			                    else if(Game.checkGameOver()==true)
	        			                    	 JOptionPane.showMessageDialog(null, "you lost :(");
	                                    } catch (NoAvailableResourcesException | InvalidTargetException ex) {
	                                        if (h.getSupplyInventory().isEmpty())
	                                            JOptionPane.showMessageDialog(null, "Supply inventory is empty");
	                                        else
	                                            JOptionPane.showMessageDialog(null, "Invalid target");
	                                        ex.printStackTrace();}
	                                }
	                            }
	                        }
	                        }
	                    }
	                }
	            }
	        });
	    }

	    


	//if (h.getTarget()!=null) {
	//try {
//	    h.useSpecial();
//	    sidepanelh();
	//} catch (NoAvailableResourcesException | InvalidTargetException ex) {
//	    if (h.getSupplyInventory().isEmpty())
//	        JOptionPane.showMessageDialog(null, "Supply inventory is empty");
//	    else
//	        JOptionPane.showMessageDialog(null, "Invalid target");
//	    ex.printStackTrace();
	//
	//
	//}}
	//else 
//		JOptionPane.showMessageDialog(null, "null target");
	//
	//}
	}
	
	  
	}