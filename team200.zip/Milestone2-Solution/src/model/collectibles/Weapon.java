package model.collectibles;

public enum Weapon {

	ARMGUN, RANGED, MELEE
}

