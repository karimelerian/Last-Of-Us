package model.collectibles;

public class Empowering extends Supply {
	
	private int coins;
	private int fullPower;
	
	public Empowering() {
		coins=50;
		fullPower=100;
	}
	
	public int getCoins() {
		return coins;
	}
	
	public int getFullPower() {
		return fullPower;
	}
	

}
